# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

一般市民閱讀城市問題的研究答案；研究者負責找出、比較與查核建議。使用者於 2026-10-14 澄清：不是讓市民體驗選址，而是我們要找答案。

## Product Purpose

以可追溯的資料與分析回答七個城市問題。先交付結論、推薦方向、比較依據及證據缺口，再讓讀者查地圖、方法與限制。參數調整是研究工具，不能替代研究者的答案。

## Positioning

答案優先的市政研究專刊；同條件地圖、Three.js 與比較圖供查核。真實觀測、官方配置原則、模型情境與待驗證的建議分開表達。

## Capabilities and Constraints

- 既有七題：補樹位置、清潔箱配置、鼠患治理、錯峰通勤、公車接駁、社區健檢及資料健檢。
- 保留清潔箱題為預設入口及全部既有有效 hash 深連結。清潔箱是現有參賽主線，此次公眾導覽不改變題目模型。
- 原生 ES modules 靜態網站，繁體中文（台灣）；固定版本 Leaflet、Three.js 同站提供。
- 可重設、儲存瀏覽器本機方案、分享參數及匯出。CSV 健檢在本機處理。
- 裝置不支援 WebGL 2 時使用圖表；街道地圖需網路。
- 真實設施快照、合成需求及模型推估必須清楚區分；不宣稱政策因果成效、現勘完成或真實安全評級。

## Brand Commitments

名稱「台北城市實驗室」與繁體中文保留。使用者確認沒有須保留的視覺特色或排除風格，並要求使用 Impeccable 重新設計。

## Topic Organization

2026-10-15起依使用者要求分成七個獨立網站。每題的資料、模型與研究集中在topics/<id>，共用工具與規範在shared，各站入口與部署產物在sites/<站名>。原整合站保留相容入口；獨立站使用各自的題目、資料、儲存與匯出。垃圾箱站延續既有地圖、歷程與桶型體驗。

共用呈現程式與靜態資產維護於 `shared/web/template/`，原整合站的可重建輸出位於 `sites/taipei-city-lab/dist/`。本次目錄整理不更改既有題目、模型意義或歷史驗收範圍。

## Evidence on Hand

`topics/*/data/`、`topics/*/model.js`、各題研究筆記與`shared/data/`為維護來源；`sites/taipei-city-lab/dist/data/snapshot.json`與`sites/taipei-city-lab/dist/data/source-catalog.json`為可重建的整合相容產物。資料取得時間為 2026-10-13；快照不是即時資料。完整筆數、資料範圍及來源界線以 README 與資料審查文件為準。

## Product Principles

- 先提出支持得住的結論，不要求市民先操作才能取得答案。
- 誠實的限制揭露不等於資料足以回答問題；不能用合成網格宣稱實際選址。
- 使用同條件基準比較，保留可重現參數。
- 提供看得懂的說明與進階研究功能。
- 資料證據與推估限制持續可見。

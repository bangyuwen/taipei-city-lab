# 台北垃圾箱研究

聚焦台北行人專用清潔箱的早期分布與撤除歷程。這是獨立的靜態站，資料與程式都由本站提供。

網站：[台北垃圾箱研究](https://taipei-waste-lab.bangyuwen.chatgpt.site)。網站程式與部署產物位於 `sites/taipei-waste-lab/`；本題資料、模型與研究入口見[垃圾箱題目目錄](../../topics/bins/README.md)。Sites 部署使用本站自己的 Git 與 `.openai/hosting.json`。

目前保留：

- 2015、2022、2024、2026 四份位置資料切換，行政區／地址搜尋、位置清單與篩選 CSV 下載。
- 有來源的撤除時間線，區分政策理由、官方存量與具日期的撤除個案。
- Three.js 桶型體驗：四種概念設計、尺寸與填滿程度、四個觀看視角、物件試投及清運門／內桶操作。
- 各版本日期、完整性、原始來源與研究筆記下載。

## 資料範圍

| 版本 | 保存資料列 | 可繪製紀錄 | 限制 |
| --- | ---: | ---: | --- |
| 2015 | 2,517 | 2,505 | 12 區保存資料，未核實完整性；12 筆座標待核對 |
| 2022 | 1,799 | 1,799 | 12 區保存資料，原調查日期與完整性未核實 |
| 2024 | 1,000 | 1,000 | 原 API 回報 1,991 筆，僅保存第一頁 |
| 2026 | 294 | 294 | 既有中心示範框，並非全市 |

保存日期不等於設置／撤除日期，本站列號不是官方箱號。不同版本缺列不直接視為撤除。完整來源與限制見[歷史分布與撤除紀錄](../../topics/bins/docs/bin-removal-history.md)、`dist/data/datasets.json` 及各版來源說明。

2026 中心示範框為經度 121.51–121.57、緯度 25.02–25.08；原始下載表有 681 列，680 列座標有效。位置地圖保留原始重疊紀錄，來源與品質紀錄保存在 `dist/data/taipei-bins-2026-study-area.provenance.json`。

## 研究筆記

研究正文集中於[本題文件目錄](../../topics/bins/docs/README.md)。修改正文後，執行 `npm run prepare-data` 會更新 `data/research/` 的獨立原始碼副本及 `dist/research/` 的網站下載，請勿直接修改這兩份衍生副本。

- [垃圾箱減少的研究脈絡](../../topics/bins/docs/bin-reduction.md)：歷史背景、政策理由與待驗證問題。
- [歷史分布與撤除紀錄](../../topics/bins/docs/bin-removal-history.md)：各版資料、撤除時間線與來源限制。
- [桶型體驗的設計假設](../../topics/bins/docs/bin-design.md)：四款概念的尺寸、試投與清運示意界線。
- [全球公共垃圾箱設計與治理比較及台北應用](../../topics/bins/docs/global-bin-practices.md)：五大洲16個案例，涵蓋桶型、配置、清運、撤除、回收與台北可借鏡的條件。

## 開發與驗證

無需安裝前端依賴。Node.js 22 以上：

```sh
npm test
npm run check
npm run preview
```

已保存的 CSV、來源紀錄與前端資產均在本專案。`npm run prepare-data` 直接從本站保存檔案重建展示資料，不依賴其他專案，不會自動下載新版本或補齊歷史缺頁。

`python scripts/check-browser.py` 使用環境既有的 Playwright 與 Chromium 檢查桌機／手機、版本切換、篩選、下載與撤除歷程操作。畫面證據寫入忽略的 `qa/`。

`python scripts/check-design-browser.py` 驗證桶型操作、桌機／手機、減少動態效果、位置資料失敗及 WebGL 不可用時的文字比較。Three.js 0.180.0 與 OrbitControls 自行託管，按需載入，版本與檔案雜湊見 `dist/vendor/three/manifest.json`。3D 體驗不依賴位置資料請求成功。

桶型入口為 `#design`。四款為本站概念，並非台北現役產品規格；試投只比較固定物件的簡化剛性截面，不預測違規、清運效率或無障礙符合性。尺寸與模型假設見[桶型體驗的設計假設](../../topics/bins/docs/bin-design.md)。

## 結構

- `dist/`：可獨立部署的網站、固定資料、Leaflet 與字型。
- `dist/history.js`：有來源的政策與撤除歷程。
- `dist/bin-scene.js`：Three.js 概念街角；`design-model.js`：尺寸與試投規則；`design-ui.js`：操作介面。
- `../../topics/bins/docs/`：研究正文與資料限制。
- `dist/research/`：由研究正文生成、維持原下載網址的網站產物。
- `.openai/hosting.json`：本站部署身分與靜態目錄。

## 授權

自寫程式採 MIT。Leaflet 與 Three.js 保留原 MIT 授權；字型保留 OFL 授權；政府資料及歷史副本依各來源條款使用。OpenStreetMap 底圖保留出處，按瀏覽範圍載入。

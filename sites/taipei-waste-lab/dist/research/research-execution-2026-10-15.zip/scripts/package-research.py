"""Package preserved research inputs and field templates for private offline use."""
import html
import json
import re
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / 'dist'
DOCS = ('bin-reduction.md', 'bin-removal-history.md', 'global-bin-practices.md', 'bin-design.md')
MARKER_OWNERS = {
    'research-synthesis': 'panel-research',
    'research-paper-records': 'panel-sources',
    'research-literature': 'panel-sources',
    'research-practice-records': 'panel-sources',
}


def inline_markdown(text):
    """Render only escaped text, emphasis and source links from local notes."""
    text = html.escape(text)
    text = re.sub(r'\[([^\]]+)\]\((https://[^\s)]+)\)',
                  r'<a href="\2" target="_blank" rel="noopener noreferrer">\1 ↗</a>', text)
    text = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', text)
    return re.sub(r'\*([^*]+)\*', r'<em>\1</em>', text)


def reference_record(item):
    esc = html.escape
    kind = '論文' if item['kind'] == 'academic' else '實務紀錄'
    method_label = '研究怎麼做' if item['kind'] == 'academic' else '實際怎麼做'
    sources = (item.get('sources') or [{'label': item['sourceLabel'], 'url': item['url']}])
    links = ''.join(f'<a href="{esc(source["url"], quote=True)}" target="_blank" rel="noopener noreferrer">{esc(source["label"])}</a>' for source in sources)
    return (f'<article class="research-reference" aria-labelledby="reference-{esc(item["id"])}">'
            f'<h4 id="reference-{esc(item["id"])}" tabindex="-1">{esc(item["title"])}</h4>'
            f'<p class="research-reference-meta">{esc(item["id"])} · {kind} · {esc(item["attribution"])}</p>'
            f'<p class="research-reference-method"><strong>{method_label}：</strong>{esc(item["method"])}</p>'
            '<dl class="research-reference-facts">'
            f'<div><dt>得到什麼</dt><dd>{esc(item["finding"])}</dd></div>'
            f'<div><dt>對台北的啟發 · 本站解讀</dt><dd>{esc(item["lesson"])}</dd></div></dl>'
            f'<p class="research-reference-limit"><strong>判讀界線：</strong>{esc(item["limitation"])}</p>'
            f'<div class="research-reference-source"><p><strong>查閱範圍：</strong>{esc(item["readingScope"])}</p><p>{esc(item["citation"])}</p>{links}</div></article>')


def literature_records(literature, catalog):
    """Keep one detailed record per paper, preferring the reviewed guide where present."""
    papers = re.findall(r'^### (L\d{2}) ([^\n]+)\n(.*?)(?=^### |^## |\Z)',
                        literature, re.M | re.S)
    assert len(papers) == 13
    reviewed = {item['id']: item for item in catalog['items'] if item['kind'] == 'academic'}
    records = []
    directory = []
    for key, title, body in papers:
        label = reviewed[key]['title'] if key in reviewed else title
        directory.append(f'<li><a href="#reference-{key}" data-research-target="reference-{key}">{key} · {html.escape(label)}</a></li>')
        if key in reviewed:
            records.append(reference_record(reviewed[key]))
        else:
            paragraphs = [p for p in body.strip().split('\n\n') if p.startswith('**')]
            assert len(paragraphs) == 4, f'Incomplete literature record: {key}'
            records.append(f'<article class="research-reference" aria-labelledby="reference-{key}">'
                           f'<h4 id="reference-{key}" tabindex="-1">{key} · {html.escape(title)}</h4>' +
                           ''.join('<p>' + inline_markdown(p) + '</p>' for p in paragraphs) + '</article>')
    assert set(reviewed) <= {key for key, _, _ in papers}
    return '\n'.join(directory), '\n'.join(records)


def render_references(index_text, catalog, literature):
    items = catalog['items']
    by_id = {item['id']: item for item in items}
    assert len(items) == len(by_id), 'Duplicate reference ID'
    for item in items:
        assert re.fullmatch(r'[A-Z][0-9]{2}', item['id']), 'Invalid reference ID'
        assert item['kind'] in ('academic', 'practice'), 'Invalid reference kind'
        for source in (item.get('sources') or [{'label': item['sourceLabel'], 'url': item['url']}]):
            assert source['url'].startswith('https://'), 'Reference source must use HTTPS'
    directory, records = literature_records(literature, catalog)
    sections = {
        'research-paper-records': directory,
        'research-literature': records,
        'research-practice-records': '\n'.join(reference_record(item) for item in items if item['kind'] == 'practice')
    }
    contexts = [
        ('siting', '配置與服務缺口',
         '需確認實際步行路徑、通行空間、服務時段與清運責任；清冊少列不能當作服務不足。',
         '尚無各點需求、現場阻礙與投放便利的完整資料，也不能由座標差異判定撤除或遷移。',
         [('siting', '看台北的分布與差異'), ('countries', '比較各地設置做法')]),
        ('collection', '清運與維護',
         '基本巡收、接單與故障備援須有人承接；感測方案需要實際調班能力。',
         '尚無台北試辦成效與完整營運工時；海外設備規格不構成本地節省的證據。',
         [('history', '看台北的歷程與紀錄'), ('countries', '比較各地清運做法')]),
        ('household', '家戶垃圾分流',
         '先確認合法投放管道的時段與可達性，再比較費率、清運、維修及停機替代；保留免費行人基本服務。',
         '尚未證實付費或改入口能減少台北家戶垃圾混入；袋子外觀與交易量不能單獨判定來源或成效。',
         [('countries', '比較家戶收運案例'), ('design', '看方案的概念示意')])
    ]
    assert len(catalog['synthesis']) == len(contexts)
    synthesis = []
    for item, (slug, topic, condition, unknown, paths) in zip(catalog['synthesis'], contexts):
        links = []
        for key in item['references']:
            assert key in by_id, f'Unknown synthesis reference: {key}'
            label = html.escape(f'{key} · {by_id[key]["title"]}', quote=True)
            links.append(f'<a href="#reference-{key}" data-research-target="reference-{key}" aria-label="{label}" title="{label}">{key}</a>')
        path_links = ''.join(f'<a href="#{target}">{html.escape(label)}</a>' for target, label in paths)
        synthesis.append(f'<article class="research-synthesis-item" aria-labelledby="conclusion-{slug}"><h3 id="conclusion-{slug}" tabindex="-1">' +
                         html.escape(topic) + '：' + html.escape(item['title']) + '</h3><p>' +
                         html.escape(item['takeaway']) + '</p><p><strong>可以先做：</strong>' + html.escape(item['action']) +
                         '</p><p><strong>成立條件：</strong>' + html.escape(condition) +
                         '</p><p class="research-unknown"><strong>仍未知：</strong>' + html.escape(unknown) +
                         '</p><p><strong>如何確認有用：</strong>' + html.escape(item['check']) +
                         '</p><div class="research-synthesis-sources"><span>依據</span>' + ''.join(links) +
                         '</div><div class="research-related-paths">' + path_links + '</div></article>')
    sections['research-synthesis'] = '\n'.join(synthesis)
    for marker, body in sections.items():
        before = index_text.split(f'<!-- {marker}-start -->')[0]
        panels = re.findall(r'<section\b[^>]*\bid="(panel-[^"]+)"', before)
        assert panels and panels[-1] == MARKER_OWNERS[marker], f'Incorrect panel owner for {marker}'
        index_text, count = re.subn(f'<!-- {marker}-start -->.*?<!-- {marker}-end -->',
                                   lambda match: f'<!-- {marker}-start -->\n{body}\n<!-- {marker}-end -->',
                                   index_text, flags=re.S)
        assert count == 1, f'Missing reference marker: {marker}'
    return index_text


def main():
    canonical = ROOT.parent.parent / 'topics/bins/research'
    docs = {name: (ROOT / 'data/research' / name).read_text() for name in DOCS}
    if canonical.is_dir():
        if (ROOT / 'research').exists():
            shutil.rmtree(ROOT / 'research')
        shutil.copytree(canonical, ROOT / 'research',
                        ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    # The portable copy links to the retained flat documents, not monorepo docs/.
    for note in (ROOT / 'research').rglob('*.md'):
        note.write_text(re.sub(r'(?<=\]\()\.\./\.\./docs/',
                               '../../dist/research/', note.read_text()))
    destination = DIST / 'research'
    if destination.exists():
        shutil.rmtree(destination)
    shutil.copytree(ROOT / 'research', destination,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    for note in destination.rglob('*.md'):
        text = re.sub(r'(?<=\]\()\.\./\.\./dist/data/', '../../data/', note.read_text())
        text = re.sub(r'(?<=\]\()\.\./\.\./dist/research/', '../', text)
        note.write_text(text)
    for name, text in docs.items():
        (destination / name).write_text(re.sub(r'(?<=\]\()\.\./data/history/', '../data/', text))
    literature = (ROOT / 'research/literature-2026-10-15/README.md').read_text()
    index = DIST / 'index.html'
    text = index.read_text()
    catalog = json.loads((ROOT / 'research/reference-guide-2026-10-16/catalog.json').read_text())
    text = render_references(text, catalog, literature)
    index.write_text(text)

    # Preserve the original relative paths so lineage checks work after extraction.
    paths = [p for p in (ROOT / 'research').rglob('*')
             if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc']
    paths += [p for p in (DIST / 'data').glob('*') if p.is_file()]
    paths += [p for p in (DIST / 'research').glob('*.md') if p.is_file()]
    paths += [ROOT / 'data/research' / name for name in DOCS]
    paths += [DIST / 'index.html', ROOT / 'scripts/package-research.py',
              ROOT / 'scripts/prepare-research-execution.py',
              ROOT / 'scripts/compare-snapshots.py', ROOT / 'scripts/analyze-coordinate-distances.py',
              ROOT / 'scripts/estimate-budget.py']
    destination = DIST / 'research/research-execution-2026-10-15.zip'
    with zipfile.ZipFile(destination, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(paths)):
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), (2026, 10, 15, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            payload = path.read_bytes()
            if path.parent == DIST / 'research' and path.suffix == '.md':
                # The archive keeps full notes under research/, not duplicate subtrees.
                payload = re.sub(r'(?<=\]\()\.\./research/', '../../research/',
                                 payload.decode('utf-8')).encode('utf-8')
            archive.writestr(info, payload)
    print(f'Packaged {len(set(paths))} files and 13 unique literature records: {destination.name}')


if __name__ == '__main__':
    main()
